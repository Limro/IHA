/**************************************
* "uart.h":                           *
* Header file for Mega32 UART driver. *
* Henning Hargaard, 13/1 2012         *
***************************************/ 
void InitUART();
char ReadChar();
void SendChar(char Ch);
/**************************************/
