/** Automatically generated file. DO NOT MODIFY */
package iha.SMAP.exercise6;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}