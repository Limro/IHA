/** Automatically generated file. DO NOT MODIFY */
package dk.iha.itsmap.jrt.serviceapp1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}