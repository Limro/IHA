package dk.iha.itsmap.jrt.serviceapp1;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class MainService extends Service {

	public final static String PLAY_ALBUM = "dk.iha.itsmap.jrt.action.PLAY_ALBUM";
	public final static String STOP_ALBUM = "dk.iha.itsmap.jrt.action.STOP_ALBUM";
	public final static String ALBUM_NAME_EXTRA = "ALBUM_NAME_EXTRA";
	public final static String ARTIST_NAME_EXTRA = "ARTIST_NAME_EXTRA";
	public final static String JrtIMainService = "MainService";

	@Override
	public void onCreate() {
		// TODO: Actions to perform when service is created.
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		startBackgroundTask(intent, startId);
//		Log.d(JrtIMainService, "called onStartCommand");
		return Service.START_STICKY;
		// return Service.START_NOT_STICKY;
		// return.Service.START_REDELIVER_INTENT;
	}

	private void startBackgroundTask(Intent intent, int startId) {
		// TODO Start a background thread and begin the processing.
		// Intent intent = new Intent(MainService.PLAY_ALBUM);
		// intent.putExtra(MainService.ALBUM_NAME_EXTRA, "United");
		// intent.putExtra(MainService.ARTIST_NAME_EXTRA, "Pheonix");
		if (intent.getAction().equals(MainService.PLAY_ALBUM)) {
			this.startPlayback(
					intent.getStringExtra(MainService.ALBUM_NAME_EXTRA),
					intent.getStringExtra(MainService.ARTIST_NAME_EXTRA));
			Log.d(JrtIMainService, "StartService " + MainService.PLAY_ALBUM);
			return;
		}
		if (intent.getAction().equals(MainService.STOP_ALBUM)) {
			Log.d(JrtIMainService, "StopService " + MainService.STOP_ALBUM);
			pausePlayback();
			this.stopSelf();
			return;
		}
	}

	/**
	 * Listing 9-6: Implementing binding on a Service
	 */
	@Override
	public IBinder onBind(Intent intent) {
		return binder;
	}

	public class MyBinder extends Binder {
		MainService getService() {
			return MainService.this;
		}
	}

	private final IBinder binder = new MyBinder();

	/**
	 * Listing 9-9: Moving a Service to the foreground
	 */
	@SuppressWarnings("deprecation")
	public void startPlayback(String album, String artist) {
		int NOTIFICATION_ID = 1;

		// Create an Intent that will open the main Activity
		// if the notification is clicked.
		Intent intent = new Intent(this, MainActivity.class);
		PendingIntent pi = PendingIntent.getActivity(this, 1, intent, 0);

		// Set the Notification UI parameters
		Notification notification = new Notification(R.drawable.ic_launcher,
				"Starting Playback", System.currentTimeMillis());
		notification.setLatestEventInfo(this, album, artist, pi);

		// Set the Notification as ongoing
		notification.flags = notification.flags
				| Notification.FLAG_ONGOING_EVENT;

		// Move the Service to the Foreground
		startForeground(NOTIFICATION_ID, notification);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		stopForeground(true);
	}

	@Override
	public void onLowMemory() {
		// TODO Auto-generated method stub
		super.onLowMemory();
		stopForeground(true);
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		super.onUnbind(intent);
		stopForeground(true);
		return true;
	}

	/**
	 * Listing 9-10: Moving a Service back to the background
	 */
	public void pausePlayback() {
		// Move to the background and remove the Notification
		stopForeground(true);
	}

}
