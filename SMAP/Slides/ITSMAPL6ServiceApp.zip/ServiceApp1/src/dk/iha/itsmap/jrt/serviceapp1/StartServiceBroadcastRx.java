package dk.iha.itsmap.jrt.serviceapp1;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.Context;

public class StartServiceBroadcastRx extends BroadcastReceiver {
	/**
	 * @see android.content.BroadcastReceiver#onReceive(Context,Intent)
	 */
	@Override public void onReceive(Context context, Intent intent) {
		// TODO Put your code here
	}
}
